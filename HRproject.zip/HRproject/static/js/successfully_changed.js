function goToLogin() {
  // Replace this with the actual login page URL or desired action
  window.location.href = "login.html";
}
